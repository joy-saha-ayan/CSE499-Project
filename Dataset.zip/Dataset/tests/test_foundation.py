import json, logging, time
from dataclasses import replace
from unittest.mock import MagicMock
import pytest, requests
from config import Settings
from src.discover_factchecks import (_transition_url,_load_checkpoint,_save_checkpoint,_migrate_checkpoint,_request_with_retry,DiscoveryError)

@pytest.fixture
def settings(tmp_path):
    return Settings(project_root=tmp_path,max_retries=3,retry_backoff_seconds=0,request_delay_seconds=0)

def state(): return {'schema_version':2,'completed':[],'retryable_failed':{},'permanently_failed':{},'articles':[],'unmatched_sitemap_urls':[],'unmatched_url_total_count':0,'unmatched_url_unique_count':0,'frontier':[]}
def yes(*args): return True

def test_503_503_200(settings):
    s=MagicMock(); s.get.side_effect=[MagicMock(status_code=503),MagicMock(status_code=503),MagicMock(status_code=200)]
    r,e,retry=_request_with_retry(s,'https://example.com/a',settings,logging.getLogger('t'),robots_checker=yes)
    assert r.status_code==200 and s.get.call_count==3

def test_timeout_retries(settings):
    s=MagicMock(); s.get.side_effect=requests.Timeout('slow')
    r,e,retry=_request_with_retry(s,'https://example.com/a',settings,logging.getLogger('t'),robots_checker=yes)
    assert r is None and retry and s.get.call_count==3

def test_robots_temp_failure_retries(settings):
    s=MagicMock(); s.get.return_value=MagicMock(status_code=200); calls={'n':0}
    def checker(*a): calls['n']+=1; return None if calls['n']==1 else True
    r,e,retry=_request_with_retry(s,'https://example.com/a',settings,logging.getLogger('t'),robots_checker=checker)
    assert r is not None and calls['n']==2

def test_five_failures_permanent():
    st=state()
    for _ in range(5): _transition_url(st,'https://a.test/x','RETRYABLE_FAILED','503',5,0)
    assert 'https://a.test/x' in st['permanently_failed'] and st['permanently_failed']['https://a.test/x']['failure_count']==5

def test_completion_removes_failure():
    st=state(); u='https://a.test/x'; _transition_url(st,u,'RETRYABLE_FAILED','x',5,0); _transition_url(st,u,'COMPLETED')
    assert u in st['completed'] and u not in st['retryable_failed'] and u not in st['permanently_failed']

def test_migrate_v1_keeps_completed(tmp_path):
    p=tmp_path/'c.json'; old={'completed':['https://a.test'],'retryable_failed':{'https://b.test':{'retry_count':1,'reason':'timeout'}},'permanently_failed':{},'articles':[{'title':'kept'}]}; p.write_text(json.dumps(old))
    got=_load_checkpoint(p); assert got['completed']==old['completed'] and got['articles']==old['articles'] and got['schema_version']==2 and p.with_suffix('.json.v1.bak').exists()

def test_future_schema_raises(tmp_path):
    p=tmp_path/'c.json'; p.write_text(json.dumps({'schema_version':99}))
    with pytest.raises(DiscoveryError,match='newer than supported'): _load_checkpoint(p)

def test_corrupt_schema_raises(tmp_path):
    p=tmp_path/'c.json'; p.write_text(json.dumps({'schema_version':2,'completed':'no','retryable_failed':{},'permanently_failed':{},'articles':[],'unmatched_sitemap_urls':[],'frontier':[]}))
    with pytest.raises(DiscoveryError): _load_checkpoint(p)

def test_cooldown_logic():
    st=state(); u='https://a.test/x'; _transition_url(st,u,'RETRYABLE_FAILED','x',5,100)
    assert st['retryable_failed'][u]['next_retry_at']>time.time()

def test_bad_transition_rejected():
    with pytest.raises(ValueError): _transition_url(state(),'https://a.test','WHATEVER')
